
function typeInHeaderText()
{
	var i = 0;
	var headerLoginText = "WELCOME TO MY WEBSITE";
	var interval = setInterval(
    function()
    {
        document.getElementById("headingStyle").innerHTML += headerLoginText.charAt(i);
        i++;
            if (i > headerLoginText.length)
            {
                clearInterval(interval);
            }
    }, 90);
}

function showElements()
{
    document.getElementById("changePageBtn").style.visibility="visible";
    document.getElementById("headingStyle").style.visibility="visible";
}

function hideElements()
{
    document.getElementById("changePageBtn").style.visibility="hidden";
    document.getElementById("headingStyle").style.visibility="hidden";
}
