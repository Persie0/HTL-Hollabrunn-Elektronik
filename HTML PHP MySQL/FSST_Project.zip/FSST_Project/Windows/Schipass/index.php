<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datenausgabe</title>
    <link rel="stylesheet" href="style.css">
</head>
<body onload="typeInHeaderText();">
    <script type="text/javascript" src="index.js"></script>	<!-- Einbindung Javascript-->
    <div class="circle-container" onmouseover="showElements()" onmouseout="hideElements()">
        <header class="bar">
            <div class="buttonHeader">
                <button class="barBtns">HOME</button>
                <button class="barBtns">DATA</button>
                <button class="barBtns">IMPRESSUM</button>
            </div>
        </header>
        <div class="text">
            <h1 id="headingStyle"></h1>
            <form method="post" action="tables.php">
              <button id="changePageBtn">SEE CURRENT DATA</button>
            </form>
        </div>
    </div>
</body>
</html>
