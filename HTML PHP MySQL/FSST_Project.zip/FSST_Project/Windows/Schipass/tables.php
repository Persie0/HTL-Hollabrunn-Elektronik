 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Datenausgabe</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <script type="text/javascript" src="index.js"></script>	<!-- Einbindung Javascript-->
    <div class="box">
      <form method="post">
          <p> Geben Sie bitte die gewünschten Daten ein:</p>
          <p> Bitte Tabelle auswählen: </p>
          <input type="radio" name="chooseTable" value="skicard"checked>  <label> Skikarten Tabelle </label>
          <br><input type="radio" name="chooseTable" value="wetterm">     <label> Temperatur Tabelle</label>
          <p> Welches Zeitintervall möchten Sie ausgeben?:</p>
          <input type="radio" name="chooseTime" value="0"checked>    <label> alle </label>
          <br><input type="radio" name="chooseTime" value="1">        <label> 1 Minute</label>
          <br><input type="radio" name="chooseTime" value="3">        <label> 3 Minuten</label>
          <br><input type="radio" name="chooseTime" value="5">        <label> 5 Minuten</label>
          <br><br><button class="barBtns" name="showT" style="left:10rem;">Ausgabe</button>
      </form>
      <form class="lastP" method="post" action="index.php">
        <button class="barBtns" name="lastPage">Home</button>
      </form>
    </div>
    </div>
    <div class="tableDiv">
      <?php
      $currentMins=date('i');
      $currentHour=date('H');
      $ip="172.18.3.72";
      $user = "fsstschool";
      $password ="admin1234()";
      $db_name ="projectdata";
      $conn = mysqli_connect($ip,$user,$password,$db_name);
      if($conn->connect_error)
      {
          die("Connection failed:" . $conn->connect_error);
      }
      if(isset($_POST['showT']))
      {

        switch($_POST['chooseTable'])
        {
          case "skicard":
            $headerTable = array("ID","Skikartennummer","Zeitpunkt");
            $data = array("ID","Skicardnr","Ts");
            $sql="Select * from skicard";
            break;
          case "wetterm":
            $headerTable = array("ID","Ort","Zeitpunkt","Temperatur");
            $data =array("id","place","Ts","temperature");
            $sql="Select * from wetterm";
        }
        echo "<table>";
        echo "<tr class=firstRowT>";
        foreach($headerTable as $inhalt)
        {
          echo "<th> $inhalt </th>";
        }
        echo "</tr>";
        $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result)>0)
        {
          while($row=mysqli_fetch_assoc($result))
          {
            if($_POST['chooseTime']!="0")
            {
              $min = substr($row['Ts'],-5,2);
              $hour = substr($row['Ts'],-8,2);
              $date = substr($row['Ts'],0,10);
              if((($currentMins-$min)>=0 && ($currentMins-$min)<=$_POST['chooseTime']) && ($currentHour - $hour)==0 && (date("Y-m-d")==$date)) //$currentHour== $hour)
              {
                echo "<tr>";
                foreach($data as $inhalt)
                {
                    echo "<td> $row[$inhalt] </td>";
                }
                echo "</tr>";
              }
            }
            else
            {
              echo "<tr>";
              foreach($data as $inhalt)
              {
                  echo "<td> $row[$inhalt] </td>";
              }
              echo "</tr>";
            }
          }
        }
      }
      ?>
      </div>
</body>
</html>
