//Pronebner Jakob 28.11.2022
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> /* read, write, close */
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <json-c/json.h>
#include <fcntl.h>
#include <mysql/mysql.h>
#include <pthread.h>
#include <stdbool.h>

void *readSkiCardNum()
{
    int fd;
    char skicardnum[38];
    char server[16] = "127.0.0.1";
    char username[16] = "root";
    char password[16] = "admin";
    char database[16] = "projectdata";
    char *cmd="insert into skicard(Skicardnr) values ('%s')";

    MYSQL* conn = mysql_init(NULL);

    if (conn == NULL) {
        printf("MySQL initialization failed");
        return NULL;
    }

    if (mysql_real_connect(conn, server, username, password, database, 0, NULL, 0) == NULL) {
        printf("Unable to connect with MySQL server\n");
        mysql_close(conn);
        return NULL;
    } 
     
    while(1)
    {
	    if((fd=open("/proc/sys/kernel/random/uuid",O_RDONLY))<0)
	    {
	    	printf("Error: Could not be opened");
	    	return NULL;
	    }
	    else
	    {
	    	if(read(fd,skicardnum,37)<0)
	    	{
	    		printf("Error: Could not read file");
	    		return NULL;
	    	}
	    }
	    close(fd);
	    char fcmd[strlen(cmd)+strlen(skicardnum)+1];
	    sprintf(fcmd,cmd,skicardnum);
	    if (mysql_query(conn,fcmd)) 
	    {
		printf("Unable to insert data into skicard table\n");
		mysql_close(conn);
		return NULL;
	    }
	    memset(skicardnum,0,sizeof(skicardnum));
	    sleep(5);
    }
    
    mysql_close(conn);
}



void *getApiData()
{
    int portno =80,jsonpos=0,resppos=0;
    int sockfd, bytes, received, total;
    char *host ="api.openweathermap.org";
    char *message_fmt = "POST /data/2.5/weather?q=%s&appid=%s&units=metric HTTP/1.0\r\n\r\n";
    char city[]="Stockerau";
    char apikey[]="9dcd22f89403774a05bff749c9b4697f";
    char message[1024], response[4096],jsonresponse[4096];
    const char *location;
    float temperature=0;
    bool isAfterBracket=false;
    struct json_object *parsed_json;
    struct json_object *main;
    struct json_object *temp;
    struct json_object *loc;
    struct hostent *serv;
    struct sockaddr_in serv_addr;
    
    char server[16] = "127.0.0.1";
    char username[16] = "root";
    char password[16] = "admin";
    char database[16] = "projectdata";
    
    MYSQL* conn = mysql_init(NULL);

    if (conn == NULL) {
        printf("MySQL initialization failed");
        return NULL;
    }
    	
    if (mysql_real_connect(conn, server, username, password, database, 0, NULL, 0) == NULL) 
    {
        printf("Unable to connect with MySQL server\n");
        mysql_close(conn);
        return NULL;
    }  
    //fill in the parameters
    sprintf(message,message_fmt,city,apikey); 
    while(1)
    {
	    //create the socket
	    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	    if (sockfd < 0) 
	    {
	    	printf("ERROR opening socket");
	    	return NULL;
	    }

	    //lookup the ip address
	    serv = gethostbyname(host);
	    if (serv == NULL) 
	    {
	    	printf("ERROR, no such host");
	    	return NULL;
	    }

	    //fill in the structure
	    
	    memset(&serv_addr,0,sizeof(serv_addr));
	    serv_addr.sin_family = AF_INET;
	    serv_addr.sin_port = htons(portno);
	    memcpy(&serv_addr.sin_addr.s_addr,serv->h_addr,serv->h_length);
	    // connect the socket
	    
	    if (connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr)) < 0)
	    { 
		printf("ERROR connecting");
		return NULL;
	    }	
	    	//send the request
	    	total = strlen(message);
	    	bytes = write(sockfd,message,total);
	    	if (bytes < 0)
	    	{
	    		printf("ERROR writing message to socket");
	    		return NULL;
	    	}

	    	//receive the response 
	    	memset(response,0,sizeof(response));
	    	total = sizeof(response)-1;
	    	bytes = read(sockfd,response,total);
	     	if (bytes < 0)
	     	{
	     		printf("ERROR reading response from socket");
	     		return NULL;
	     	}
	    	//close the socket
	   	close(sockfd);
	    
	    
	    	//getting rid of json-format header
	    	memset(jsonresponse,0,sizeof(jsonresponse));
	   	while(resppos<strlen(response))
	   	{
	   		if(response[resppos]=='{' || isAfterBracket)
	   		{
	   			jsonresponse[jsonpos]=response[resppos];
	   			jsonpos++;
	   			isAfterBracket=true;
	   		}
	   		resppos++;
	   	}
	   	jsonresponse[resppos]='\0';
	   	//reset positions
	   	isAfterBracket=false;
	   	jsonpos=0;
	   	resppos=0;
	   	//extract temperature and location out of response
	   	parsed_json =json_tokener_parse(jsonresponse);
	    	json_object_object_get_ex(parsed_json,"main",&main);
	    	json_object_object_get_ex(main,"temp",&temp);
	    	json_object_object_get_ex(parsed_json,"name",&loc);
	    	temperature=json_object_get_double(temp);
	    	location=json_object_get_string(loc);
	    	
	    	
		char *cmd="insert into wetterm(temperature,place) values ('%.2f','%s')";
		char fcmd[strlen(cmd)+strlen(location)+5+1];
		sprintf(fcmd,cmd,temperature,location);
		if (mysql_query(conn,fcmd)) 
		{
			printf("Unable to insert data into wetterm table\n");
			mysql_close(conn);
			return NULL;
		}
		memset(response,0,sizeof(response));
		memset(jsonresponse,0,sizeof(jsonresponse));
		sleep(6);
	}

    mysql_close(conn);
    	
}

int main(int argc,char *argv[])
{
   pthread_t thread_id1;
   pthread_t thread_id2;
   pthread_create(&thread_id1,NULL,readSkiCardNum,NULL);
   pthread_create(&thread_id2,NULL,getApiData,NULL);
   pthread_join(thread_id1,NULL);
   pthread_join(thread_id2,NULL);
   return 0;
}

