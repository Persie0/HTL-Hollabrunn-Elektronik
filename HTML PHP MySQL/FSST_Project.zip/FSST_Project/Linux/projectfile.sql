use projectdata
drop table skicard;
drop table wetterm;

create table skicard
(
	ID int NOT NULL AUTO_INCREMENT,
	Skicardnr varchar(60),
	Ts TIMESTAMP  DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(ID)
);

create table wetterm
(
	id int(10) NOT NULL AUTO_INCREMENT,
	place varchar(60),
	Ts timestamp DEFAULT CURRENT_TIMESTAMP,
	temperature float,
	PRIMARY KEY(id)
);
